// For Firebase JS SDK v7.20.0 and later, measurementId is optional
var firebaseConfig = {
    apiKey: "......................",
    authDomain: "......................",
    databaseURL: "......................",
    projectId: "......................",
    storageBucket: ".......................appspot.com",
    messagingSenderId: "......................",
    appId: "1:......................:web:4a4470fed53f34f7ed82de",
    measurementId: "......................"
  };
